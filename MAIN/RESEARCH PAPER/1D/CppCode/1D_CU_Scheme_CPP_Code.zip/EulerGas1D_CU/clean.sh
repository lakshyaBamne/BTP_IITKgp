# bash script to clear all the un necessary files
find . -name "*.txt" -type f -delete
find . -name "*.gif" -type f -delete
find . -name "*.png" -type f -delete

find . -name "*.exe" -type f -delete
find . -name "*.x" -type f -delete
find . -name "*.o" -type f -delete
find . -name "*.out" -type f -delete
